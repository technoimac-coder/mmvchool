<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/db.php';
$database = require_database();

$statements = [
    "CREATE TABLE IF NOT EXISTS leave_requests (
      id varchar(30) NOT NULL, user_id varchar(20) NOT NULL, user_name varchar(255) NOT NULL,
      user_position varchar(255) NOT NULL DEFAULT '', department varchar(255) NOT NULL DEFAULT '',
      organization varchar(255) NOT NULL DEFAULT '', written_at varchar(255) NOT NULL DEFAULT '',
      leave_type varchar(30) NOT NULL, other_leave_details varchar(255) DEFAULT NULL,
      start_date date NOT NULL, end_date date NOT NULL, total_days int NOT NULL, reason text NOT NULL,
      contact_address text, contact_phone varchar(50) DEFAULT NULL, leave_stats json DEFAULT NULL,
      signature_url longtext, status varchar(30) NOT NULL DEFAULT 'pending',
      current_stage varchar(40) NOT NULL DEFAULT 'admin_review', admin_review json DEFAULT NULL,
      deputy_approval json DEFAULT NULL, director_approval json DEFAULT NULL,
      created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (id), KEY leave_requests_user_id (user_id), KEY leave_requests_stage (status, current_stage),
      CONSTRAINT leave_requests_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    "CREATE TABLE IF NOT EXISTS notifications (
      id bigint unsigned NOT NULL AUTO_INCREMENT, user_id varchar(20) NOT NULL,
      title varchar(255) NOT NULL, message text NOT NULL, module varchar(50) NOT NULL,
      related_id varchar(50) DEFAULT NULL, read_at datetime DEFAULT NULL,
      created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id),
      KEY notifications_user_read (user_id, read_at, created_at),
      CONSTRAINT notifications_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
];

foreach ($statements as $statement) $database->exec($statement);
fwrite(STDOUT, "Leave workflow tables are ready.\n");
