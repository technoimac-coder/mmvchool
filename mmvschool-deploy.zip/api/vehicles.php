<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/line-notifier.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$database = require_database();
$currentUser = require_user();

if ($method === 'GET') {
    $action = $_GET['action'] ?? 'bookings';
    if ($action === 'fleet') {
        $stmt = $database->query("SELECT * FROM vehicles ORDER BY id ASC");
        api_respond(["status" => "success", "data" => $stmt->fetchAll()]);
    } else {
        $privilegedRoles = ['admin', 'director', 'deputy_budget', 'driver'];
        if (in_array($currentUser['role'] ?? '', $privilegedRoles, true)) {
            $stmt = $database->query("SELECT * FROM vehicle_bookings ORDER BY created_at DESC");
        } else {
            $stmt = $database->prepare("SELECT * FROM vehicle_bookings WHERE user_id = ? ORDER BY created_at DESC");
            $stmt->execute([$currentUser['id']]);
        }
        $rows = $stmt->fetchAll();
        foreach ($rows as &$r) {
            $r['teachersList'] = json_decode($r['teachers_list'] ?? '[]', true);
            $r['studentsList'] = json_decode($r['students_list'] ?? '[]', true);
        }
        api_respond(["status" => "success", "data" => $rows]);
    }
} elseif ($method === 'POST') {
    require_csrf();
    $input = json_body();
    $action = $input['action'] ?? 'create';

    if ($action === 'create') {
        foreach (['destination', 'purpose', 'startDate', 'startTime', 'endDate', 'endTime'] as $requiredField) {
            if (trim((string) ($input[$requiredField] ?? '')) === '') {
                api_error('กรุณากรอกข้อมูลการขอใช้รถให้ครบถ้วน', 422, 'validation_error');
            }
        }
        $id = 'VB-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $stmt = $database->prepare("INSERT INTO vehicle_bookings
            (id, user_id, user_name, user_phone, department, destination, purpose, passenger_count, approval_letter_no, teachers_list, students_list, start_date, start_time, end_date, end_time, booking_stage, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'deputy_budget_allocation', 'pending')");
        
        $stmt->execute([
            $id,
            $currentUser['id'],
            $currentUser['name'],
            $currentUser['phone'] ?? '',
            $currentUser['department'] ?? '',
            $input['destination'] ?? '',
            $input['purpose'] ?? '',
            $input['passengerCount'] ?? 1,
            $input['approvalLetterNo'] ?? '',
            json_encode($input['teachersList'] ?? [], JSON_UNESCAPED_UNICODE),
            json_encode($input['studentsList'] ?? [], JSON_UNESCAPED_UNICODE),
            $input['startDate'] ?? date('Y-m-d'),
            $input['startTime'] ?? '08:00',
            $input['endDate'] ?? date('Y-m-d'),
            $input['endTime'] ?? '17:00'
        ]);

        line_notify_event('มีคำขอใช้รถส่วนกลางใหม่', [
            'เลขที่' => $id,
            'ผู้ขอ' => $currentUser['name'],
            'ปลายทาง' => $input['destination'],
            'วัตถุประสงค์' => $input['purpose'],
            'วันที่' => $input['startDate'] . ' ' . $input['startTime'],
        ]);

        api_respond(["status" => "success", "bookingId" => $id], 201);
    } elseif ($action === 'allocate') {
        require_roles('admin', 'director', 'deputy_budget');
        $stmt = $database->prepare("UPDATE vehicle_bookings SET
            is_external_rental = ?,
            vehicle_id = ?,
            rental_details = ?,
            rental_cost = ?,
            assigned_driver_id = ?,
            deputy_comment = ?,
            booking_stage = ?,
            status = 'approved'
            WHERE id = ?");
        
        $stmt->execute([
            $input['isRental'] ? 1 : 0,
            $input['vehicleId'] ?? null,
            $input['rentalDetails'] ?? null,
            $input['rentalCost'] ?? 0,
            $input['driverId'] ?? null,
            $input['comment'] ?? '',
            $input['isRental'] ? 'completed' : 'driver_ack',
            $input['bookingId']
        ]);

        $bookingStatement = $database->prepare('SELECT id, user_name, destination FROM vehicle_bookings WHERE id = ? LIMIT 1');
        $bookingStatement->execute([$input['bookingId']]);
        $updatedBooking = $bookingStatement->fetch();
        if ($updatedBooking) {
            line_notify_event('จัดสรรรถให้คำขอแล้ว', [
                'เลขที่' => $updatedBooking['id'],
                'ผู้ขอ' => $updatedBooking['user_name'],
                'ปลายทาง' => $updatedBooking['destination'],
                'ดำเนินการโดย' => $currentUser['name'],
            ]);
        }

        api_respond(["status" => "success"]);
    } elseif ($action === 'driver_ack') {
        require_roles('admin', 'driver');
        if (($currentUser['role'] ?? '') === 'driver') {
            $stmt = $database->prepare(
                "UPDATE vehicle_bookings SET booking_stage = 'driver_ack' WHERE id = ? AND assigned_driver_id = ?"
            );
            $stmt->execute([$input['bookingId'] ?? '', $currentUser['id']]);
        } else {
            $stmt = $database->prepare("UPDATE vehicle_bookings SET booking_stage = 'driver_ack' WHERE id = ?");
            $stmt->execute([$input['bookingId'] ?? '']);
        }
        if ($stmt->rowCount() !== 1) {
            api_error('ไม่พบรายการหรือคุณไม่มีสิทธิ์รับงานนี้', 404, 'booking_not_found');
        }
        line_notify_event('พนักงานขับรถรับงานแล้ว', [
            'เลขที่' => $input['bookingId'] ?? '',
            'ผู้รับงาน' => $currentUser['name'],
        ]);
        api_respond(["status" => "success"]);
    }
    api_error('ไม่รู้จักคำสั่งที่ร้องขอ', 400, 'unknown_action');
}

api_error('ไม่รองรับวิธีการเรียกนี้', 405, 'method_not_allowed');
